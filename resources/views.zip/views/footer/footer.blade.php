<footer class="footer">
    <div class="container">
        <div class="copyright pull-right"><b>
                &copy; @lang('главная.авторские_права')</b> <i class="fa fa-check-circle" id="cs10"
                                                                              aria-hidden="true"></i>
        </div>
    </div>
</footer>